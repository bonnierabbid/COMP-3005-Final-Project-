
INSERT INTO bookstore
VALUES  (1,'Ottawa','BookstoreOne'),
        (2,'Ottawa','BookstoreTwo'),
        (3,'Ottawa','BookstoreThree');


INSERT INTO warehouse
VALUES  (1,'WarehouseOne', 'Ottawa');

INSERT INTO publishers
VALUES  ('A','Canada','aaa@mail.com','111-111-1111', '10000000000'),
        ('B','Canada','bbb@mail.com','222-222-2222', '20000000000'),
        ('C','Canada','ccc@mail.com','333-333-3333', '30000000000');

INSERT INTO book
VALUES  ('Catching Fire 1(The Hunger Games)','Suzanne Collins',1,'20015','Fiction',200,11,1,20),
        ('Catching Fire 2(The Hunger Games)','Suzanne Collins',1,'20016','Fiction',200,11,1,20),
        ('Catching Fire 3(The Hunger Games)','Suzanne Collins',1,'20017','Fiction',200,11,1,20),
        ('Hamilton: The Revolution','Lin-Manuel Miranda',2,'20027','Non Fiction',200,54,1,20),
        ('Harry Potter and the Chamber of Secrets','J.K. Rowling',2,'20029','Fiction',200,30,1,20),
        ('Harry Potter and the Cursed Child','J.K. Rowling',2,'20030','Fiction',200,12,1,20),
        ('Harry Potter and the Goblet of Fire','J. K. Rowling',2,'20031','Fiction',200,18,1,20),
        ('Harry Potter and the Prisoner of Azkaban','J.K. Rowling',2,'20032','Fiction',200,30,1,20),
        ('Harry Potter and the Sorcerers Stone','J.K. Rowling',2,'20033','Fiction',200,22,1,20),
        ('Harry Potter Coloring Book','Scholastic',2,'20034','Non Fiction',200,9,1,20),
        ('Harry Potter Paperback Box Set (Books 1-7)','J. K. Rowling',2,'20035','Fiction',200,52,1,20),
        ('The Fault in Our Stars 1','John Green',3,'20050','Fiction',200,13,1,20),
        ('The Fault in Our Stars 2','John Green',3,'20051','Fiction',200,13,1,20),
        ('The Fault in Our Stars 3','John Green',3,'20052','Fiction',200,7,1,20),
        ('The Fault in Our Stars 4','John Green',3,'20053','Fiction',200,1,1,20),
        ('To Kill a Mockingbird','Harper Lee',3,'20073','Fiction',200,7,1,20);


INSERT INTO sale
VALUES  ('Catching Fire 1(The Hunger Games)','A',10),
        ('Catching Fire 2(The Hunger Games)','A',10),
        ('Catching Fire 3(The Hunger Games)','A',10),
        ('Hamilton: The Revolution','B',20),
        ('Harry Potter and the Chamber of Secrets','B',20),
        ('Harry Potter and the Cursed Child','B',20),
        ('Harry Potter and the Goblet of Fire','B',20),
        ('Harry Potter and the Prisoner of Azkaban','B',20),
        ('Harry Potter and the Sorcerers Stone','B',20),
        ('Harry Potter Coloring Book','B',20),
        ('Harry Potter Paperback Box Set (Books 1-7)','B',20),
        ('The Fault in Our Stars 1','C',5),
        ('The Fault in Our Stars 2','C',5),
        ('The Fault in Our Stars 3','C',5),
        ('The Fault in Our Stars 4','C',5),
        ('To Kill a Mockingbird','C',5);

