a) Retrieve the account_number and password of the user who matches the input values: account, password.
Please replace your registered account number and password in the '' fields.

SELECT account_number, password 
FROM book_user 
WHERE account_number = 'account' AND password = 'password';


b) Retrieve inforamtion of books which include the input string.
Please replace a value you want to search in the '' fields.

SELECT book_name, author, isbn, genre 
FROM book 
WHERE position('string' in LOWER(book_name))>0 
OR position('string' in LOWER(author))>0
OR position('string' in LOWER(isbn))>0
OR position('string' in LOWER(genre))>0



c) Retrieve books in cart with basket id and quantity

SELECT basket_id, book_name, quantity FROM checkout_basket