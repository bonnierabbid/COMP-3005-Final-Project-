# User side interface
# Primary procedures: Register -> Sign in -> 
# -> Browse -> Select a book -> Add to Cart -> Checkout

import psycopg2
from config import config

# Check the connection to Bookstore database
def check_connect():
    """ Connect to the PostgreSQL database server """
    conn = None
    try:
        # read connection parameters
        params = config()

        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)
		
        # create a cursor
        cur = conn.cursor()
        
	    # execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)
       
	    # close the communication with the PostgreSQL
        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            print('Database connection closed.')

# Make a selection of operations
def choose():
    print("1. Add a book  2. Delete a book  3. Add publisher info  4. Print report ")
    choice = input()

    if choice == '1':
        addBook()
    if choice == '2':
        deleteBook()
    if choice == '3':
        addPublisher()
    if choice == '4':
        report()
    else:
        print("Please enter a valid choice.")
        choose()

# Add a new book
def addBook():
    print("Please enter the following information to add a book.")

    print("Bookname: ")
    name = input()

    print("Author: ")
    author = input()

    print("Bookstore id (please enter a number between 1-3): ")
    store = input()

    print("ISBN: ")
    isbn = input()

    print("Genre: ")
    genre = input()

    print("Number of pages: ")
    pages = input()

    print("Price: ")
    price = input()

    print("Stock: ")
    quantity = input()

    """ insert a new book into the book table """
    sql = """INSERT INTO book(book_name, author, bookstore_id, isbn, genre, number_pages, price, warehouse_id, quantity)
             VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s);"""
    conn = None

    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
        # execute the INSERT statement
        cur.execute(sql, (name,author,store, isbn, genre, pages, price, '1', quantity))
        # commit the changes to the database
        conn.commit()

        print("Adding new book: ")
        print(name,author,store, isbn, genre, pages, price, '1', quantity)
        # close communication with the database
        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()


# Delete a book
def deleteBook():
    print("Please enter the book name to delete a book.")

    print("Bookname: ")
    name = input()


    """ delete a book by book name """
    conn = None

    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
        # execute the UPDATE  statement
        cur.execute("DELETE FROM book WHERE book_name = %s", (name,))
        # Commit the changes to the database
        conn.commit()
        print("** " + name + " has been deleted.")
        # Close communication with the PostgreSQL database
        cur.close()


    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()



# Add a new publisher
def addPublisher():
    print("Please enter the following information to add a publisher.")

    print("Publisher name (please enter 'D', 'E', 'F', etc.): ")
    name = input()

    print("Address: ")
    address = input()

    print("Email (please follow the format xxx@mail.com): ")
    email = input()

    print("Phone (xxx-xxx-xxxx): ")
    phone = input()

    print("Bank account (11 digits): ")
    bank = input()


    """ insert a new publisher into the publishers table """
    sql = """INSERT INTO publishers(publisher_name, address, email_address, phone_number, banking_account)
             VALUES(%s, %s, %s, %s, %s);"""
    conn = None

    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
        # execute the INSERT statement
        cur.execute(sql, (name, address, email, phone, bank))
        # commit the changes to the database
        conn.commit()

        print("Adding new publisher: ")
        print(name, address, email, phone, bank)
        # close communication with the database
        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()



# Print report
def report():
    print("** Printing report. **")
    
    conn = None
    
    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
        # execute the SELECT  statement
        cur.execute("SELECT book_name, publisher_name, percentage FROM sale")
        results = cur.fetchall()
        print(results)
        # Close communication with the PostgreSQL database
        cur.close()


    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()



def main():

    check_connect()

    print("** Welcome back! Please select operations. **")
    choose()

main()