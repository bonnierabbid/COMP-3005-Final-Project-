# User side interface
# Primary procedures: Register -> Sign in -> Browse -> Add to Cart -> Checkout

import psycopg2
from config import config
from datetime import datetime, timezone
time = datetime.now(timezone.utc)


# Stores the current user who has signed in
identity = None


# PostgreSQL sever connection method followed the guildline from:
# https://www.postgresqltutorial.com/postgresql-python/

# Check the connection to Bookstore database
def check_connect():
    """ Connect to the PostgreSQL database server """
    conn = None
    try:
        # read connection parameters
        params = config()

        # connect to the PostgreSQL server
        print('Connecting to the PostgreSQL database...')
        conn = psycopg2.connect(**params)
		
        # create a cursor
        cur = conn.cursor()
        
	    # execute a statement
        print('PostgreSQL database version:')
        cur.execute('SELECT version()')

        # display the PostgreSQL database server version
        db_version = cur.fetchone()
        print(db_version)
       
	    # close the communication with the PostgreSQL
        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()
            print('Database connection closed.')


# Let user sign-in
def signin():
    print("** Please enter your account number and password to sign-in. **")
    
    print("Account:")
    account = input()

    print("Password:")
    password = input()

    # Check whether the input info matches a record in database
    exist = get_user(account, password)

    if exist:
        global identity 
        identity= account
        print("**You have sign-in successfully. Current User id: " + identity +" **")
    else:
        print("Account number or password wrong.")

    # User can start to browse for books after signing in. 
    browse()

# To find wheter the user who is signing in exist in the database
def get_user(account, password):

    exist = False
    conn = None
    try:
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute("SELECT account_number, password FROM book_user WHERE account_number = %s AND password = %s", (account, password,))
        exist = cur.fetchone() is not None
        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)

    finally:
        if conn is not None:
            conn.close()
    
    return exist


# Let user register and then sign-in
def register():
    print("** Please enter the following information to register. **")

    print("Fullname:")
    fullname = input()

    print("Password:")
    password = input()

    # Add information to database
    account_number = insert_user(password, fullname, time)
    print("You have registered successfully. ")
    print("Your account_number is: " + str(account_number))
    print("Please sign-in now.")

    signin()


# Once registered, add information of the new user into the book_user table.
def insert_user(password, fullname, time):
    """ insert a new user into the User table """
    sql = """INSERT INTO book_user(password, full_name, registration_time)
             VALUES(%s, %s, %s) RETURNING account_number;"""
    conn = None
    try:
        # read database configuration
        params = config()
        # connect to the PostgreSQL database
        conn = psycopg2.connect(**params)
        # create a new cursor
        cur = conn.cursor()
        # execute the INSERT statement
        cur.execute(sql, (password,fullname,time))
        # get the generated id back
        account_number = cur.fetchone()[0]
        # commit the changes to the database
        conn.commit()
        print("Adding new user: ")
        print(account_number,password,fullname,time)
        # close communication with the database
        cur.close()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
        if conn is not None:
            conn.close()

    return account_number


# Browsing books using the input
def browse():

    print("===========================================================")
    # Let user input a search key
    print("Please type in keywords to seach for a book.")
    searchkey = input()

    conn = None

    sql = """SELECT book_name, author, isbn, genre FROM book 
             WHERE position(%s in LOWER(book_name))>0 
             OR position(%s in LOWER(author))>0
             OR position(%s in LOWER(isbn))>0
             OR position(%s in LOWER(genre))>0"""

    try:
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute(sql, (searchkey,searchkey,searchkey,searchkey))

        results = cur.fetchall()

        # Print the results found
        if results:
            print(results)

            # Let user choose to add to cart or keep browsing
            print("** To add a book to cart, type + ** ")
            print("** To search for other books, type # ** ")
            choice = input()
            if choice == '+':
                addToCart()
            if choice == '#':
                browse()

        # Let user search for other books if no result found.
        else:
            print("No result.")
            browse()

        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)

    finally:
        if conn is not None:
            conn.close()


# Enter book name to add to cart
def addToCart():
    print("===========================================================")
    print("Enter the full name of the book to add to cart.")
    book = input()

    exist = False
    conn = None

    try:
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute("SELECT book_name FROM book WHERE book_name = %s ", (book,))
        exist = cur.fetchone() is not None

        # If the book exist in record, add to cart, or else ask to enter again.
        if exist:
            sql = """INSERT INTO checkout_basket(basket_id, book_name, quantity)
                     VALUES(%s, %s, %s);"""

            cur.execute(sql, (1,book,1))
            conn.commit()

            print("** Your book is added to basket. **")
            print("===========================================================")
            print("** To add another book to cart, type + ** ")
            print("** To view your cart and check out, type $ ** ")
            print("** To get back for browsing books, type # ** ")
            choice = input()
            if choice == '+':
                addToCart()
            if choice == '#':
                browse()
            if choice == '$':
                checkout()

        else:
            print("Book not exist or entered wrong name.")
            addToCart()

        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)

    finally:
        if conn is not None:
            conn.close()
    
    return exist

# View cart and check out 
def checkout():
    print("===========================================================")
    print("** Here are the books in your cart. **")

    conn = None
    try:
        params = config()
        conn = psycopg2.connect(**params)
        cur = conn.cursor()
        cur.execute("SELECT basket_id, book_name, quantity FROM checkout_basket")
        
        # Get all books in cart
        results = cur.fetchall()
        print(results)

        print("===========================================================")
        print("** To get back for browsing books, type # ** ")
        print("** To check out, type $ ** ")
        choice = input()
        if choice == '#':
            browse()
        if choice == '$':
            global identity 
            account = identity
            address = input("Please enter your shipping address")
            sql = """INSERT INTO book_order(order_number, account_number, order_time, total_price, address)
                     VALUES(%s, %s, %s, %s, %s);"""

            cur.execute(sql, (1, account, time, 50, address))
            conn.commit()
            current = str(time)
            print("Order number: 1  Account: " + account + "  Order_time: " + current + "  Total: 50  Address: " + address) 
            print("Thank you! You order is placed. Track your order with order number: 1.")
            print("===========================================================")

        cur.close()

    except (Exception, psycopg2.DatabaseError) as error:
        print(error)

    finally:
        if conn is not None:
            conn.close()


def main():

    check_connect()

    print("** Welcome to Look Inna Book! Please sign-in or register. **")
    print("1. Sign-in  2. Register")

    choice = input()

    if choice == "1":
        signin()
    elif choice == "2":
        register()
    else:
        print("Please type 1 or 2.")


main()
